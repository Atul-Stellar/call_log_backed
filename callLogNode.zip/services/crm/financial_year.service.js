

exports.getlatestFY = async ()=>{
    return await fina
}