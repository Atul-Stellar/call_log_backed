const InitCkInv = require("./initCkInv");

const syncCkInv = async () => {
  let link = "NA";
  InitCkInv(link);
};

module.exports = syncCkInv;
