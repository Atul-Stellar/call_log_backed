const { Joi } = require("express-validation");

exports.callLogStoreSchema = {
    body: Joi.object({
        name: Joi.string().optional(),
        number: Joi.string().min(10).max(10).pattern(/^\d+$/).required(),
        fk_call_type:Joi.number().required(),
        duration: Joi.number().required(),
        date: Joi.date().required(),
        time: Joi.string().required(),
      }),
};